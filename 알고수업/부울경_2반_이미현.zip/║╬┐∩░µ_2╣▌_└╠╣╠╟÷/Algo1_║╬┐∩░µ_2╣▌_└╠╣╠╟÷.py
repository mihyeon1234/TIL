T = int(input())
for t in range(1, T+1):
    n = int(input())
    li = list(map(int, input().split()))
    li = [0] + li + [0]
    reli = [0]*n
    re = 0
    for i in range(len(li)-2):
        if li[i] <= li[i+1] and li[i+1] >= li[i+2]:
            reli[i] = 1
            re += 1

    for i in range(len(reli)-1):
        if reli[i]==1 and reli[i+1]==1:
            reli[i] = 0
    print(f'#{t} {sum(reli)}')




